import requests, json, csv
from bs4 import BeautifulSoup

def flatten_dict(data, parent_key='', sep='_'):
    items = []
    for key, value in data.items():
        new_key = parent_key + sep + key if parent_key else key
        if isinstance(value, dict):
            items.extend(flatten_dict(value, new_key, sep).items())
        else:
            items.append((new_key, value))
    return dict(items)

product_list_header = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "en-US,en;q=0.9",
    "Cookie": "_tt_enable_cookie=1; _ttp=ZvbJCwGEoaWLYnSQzOez4fNrCXB; _cls_v=a2550488-cf3b-4b47-8a2d-dce53e02555c; mdLogger=false; kampyle_userid=1038-0cdb-8ef5-b6dd-79e6-7fb1-9dec-dc0a; LAST_INVITATION_VIEW=1716750213693; DECLINED_DATE=1716751632356; tangiblee:widget:user=c8f7b3b4-9e86-455c-a701-129907938cf5; __exponea_etc__=91d872fb-4c56-4760-a81c-49052d201e8e; regionName_key=CUNDINAMARCA; region=10; ZONE_NAME=BOGOTA D.C.; comuna=1; usrLocation=10; municipal_name=ZONA NORTE; municipal=24677; AMCVS_867134FA53CCF4BE0A490D44%40AdobeOrg=1; _cls_s=64bbaf20-996b-4e92-b9e9-3a0b197dcc95:1; s_cc=true; dy_fs_page=www.homecenter.com.co%2Fhomecenter-co%2Flanding%2Fcat1670130%2Fsillas; _dy_c_exps=; _dy_c_att_exps=; _dy_soct=531438.1016959.1717135670*726513.1390447.1717135670*471628.856028.1717135670; ADRUM=s=1717135691217&r=https%3A%2F%2Fwww.homecenter.com.co%2Fhomecenter-co%2Flanding%2Fcat1670130%2FSillas%3F0; _clck=1u8kmqm%7C2%7Cfm9%7C0%7C1609; agmodal=1; __CONTENT_exp=ct-88; kampylePageLoadedTimestamp=1717252192605; _uetvid=329b82d01cc811ef821729601ec45865; __CO_exp=comCo-70; experience=CATALYST; __cf_bm=FF9O4PBAD6u35gYTnCVD8nDgDL41SbABvf2iXU1hN1k-1718284214-1.0.1.1-8UgECddoXf_1wuZ180aaEx.EEeYGkVZyyHnmGlXW6AZDjtoJLPDMzDf8nvkO2jrvmh4nBkRWULBvxfumaPK5Pw; _cfuvid=HLc5JFeBb8M.am0FASjG8azIMsdkV9kBjMreMQcbAq8-1718284214886-0.0.1.1-604800000; asid=1718284218828-1718327418828; cf_clearance=rFgX20_Q_ZNqGsZd25PgTpA6MAua8Jcq7vU6NnTNqqo-1718284221-1.0.1.1-SElbUi2YWxTv3kIqFi7ZHUla2ipSNOaz3DxQRdmrGrsaDlUjufC9efzl0Mh.aLHzJM.kQtJtwqIbok_lmAehCg; pspCombination=; _ga=GA1.1.323852251.1716749900; _gcl_au=1.1.85558889.1716749899.1217406365.1718284605.1718284605; kampyleUserSession=1718284606169; kampyleUserSessionsCount=17; kampyleUserPercentile=99.11300733896324; QueueITAccepted-SDFrts345E-V3_socosinivajunebrowse=EventId%3Dsocosinivajunebrowse%26QueueId%3D00000000-0000-0000-0000-000000000000%26RedirectType%3Dafterevent%26IssueTime%3D1718284245%26Hash%3Df439bc525a01d1bd1b235d800fc48db160a0954bafe3edac0d3f30e7bbf42f40; _ga_J705NTY1ZS=GS1.1.1718284587.18.0.1718284718.60.0.0; _ga_1H2WCS4TRM=GS1.1.1718284601.14.0.1718284718.0.0.0; pspExperience=eyJQU0UiOiJGUEFZIiwiQkFOQ09fRkFMQUJFTExBX0RFQklUX0NBUkQiOiJGUEFZIn0; forcePspExperience=eyJQU0UiOiJGUEFZIiwiQkFOQ09fRkFMQUJFTExBX0RFQklUX0NBUkQiOiJGUEFZIn0; kampyleSessionPageCounter=2; s_sq=flblascoprod%3D%2526c.%2526a.%2526activitymap.%2526page%253Dhome%2526link%253DSof%2525C3%2525A1s%2526region%253Dmenu-desktop%2526pageIDType%253D1%2526.activitymap%2526.a%2526.c%2526pid%253Dhome%2526pidt%253D1%2526oid%253Dhttps%25253A%25252F%25252Fwww.homecenter.com.co%25252Fhomecenter-co%25252Fcategory%25252Fcat10334%25252Fsofas%25252F%2526ot%253DA; AMCV_867134FA53CCF4BE0A490D44%40AdobeOrg=179643557%7CMCIDTS%7C19888%7CMCMID%7C14599812547796510987552716044439479855%7CMCAID%7CNONE%7CMCOPTOUT-1718291945s%7CNONE%7CvVersion%7C5.5.0%7CMCAAMLH-1717856978%7C9%7CMCAAMB-1718284585%7Cj8Odv6LonN4r3an7LhD3WZrU1bUpAkFkkiY1ncBR96t2PTI",
    "Priority": "u=0, i",
    "Referer": "https://www.homecenter.com.co/homecenter-co/",
    "Sec-Ch-Ua": "\"Google Chrome\";v=\"125\", \"Chromium\";v=\"125\", \"Not.A/Brand\";v=\"24\"",
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": "\"Windows\"",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "same-origin",
    "Sec-Fetch-User": "?1",
    "Service-Worker-Navigation-Preload": "true",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
}


urls = [
    "https://www.homecenter.com.co/homecenter-co/category/cat10334/sofas/",
    "https://www.homecenter.com.co/homecenter-co/category/cat10340/sofa-camas/",
    "https://www.homecenter.com.co/homecenter-co/category/cat10328/sillas-reclinables-y-descanso/",
    "https://www.homecenter.com.co/homecenter-co/category/cat3690001/juegos-de-sala/",
    "https://www.homecenter.com.co/homecenter-co/category/cat1670283/sillones-y-poltronas/",
    "https://www.homecenter.com.co/homecenter-co/category/cat1670036/centros-de-entretenimiento-y-muebles-para-tv/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat10344/juegos-de-comedor/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat1670091/mesas-de-comedor/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat4840042/consolas-y-bifes/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat10338/sillas-para-bar/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat1670118/muebles-para-bar/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat10310/closets-y-armarios/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat1670037/mesas-de-noche/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat1660049/camas/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat6040003/comodas-y-tocadores/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat1370016/cabeceros-para-cama/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat1660051/camas-infantiles-y-cunas/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat90508/colchones-sencillos/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat90509/colchones-semidobles/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat90510/colchones-dobles/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat90268/colchones-queen/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat90622/colchones-king/",
    # "https://www.homecenter.com.co/homecenter-co/category/cat740055/base-cama-y-colchon/",
    ]


result = []
page = 1
product_urls = []
for url in urls:
    while True:
        page_url = f'{url}?currentpage={page}'

        response = requests.get(page_url, headers=product_list_header)
        print(response.status_code)
        soup = BeautifulSoup(response.content, "html.parser")
        product_data = soup.find("script").text.split('"itemOffered":')[1].split(']')[0]
        products = product_data.split('"@type":"Product",')[1:]
        # products.append()
        for product in products:
            product_urls.append(product.split('"url":"')[1].split('"')[0])
        
        page +=1
        print(page)
        # if page == 3:
        #     break
        if len(products) <28:
            break

    for product_url in product_urls:
        if product_url == "/homecenter-co/product/550982/sofa-stars-40x163x64-verde-menta/550982/":
            pass
        else:
            response = requests.get(f'https://www.homecenter.com.co{product_url}')
            product_name = ""
            # Declare the variables
            product_alto = ""
            product_ancho = ""
            product_fondo = ""
            product_largo = ""
            product_profundidad = ""

            product_marca = ""
            product_material_tapiz = ""
            product_material_structure = ""
            product_color = ""
            product_capacity = ""
            product_weight = ""
            product_guarantee_time = ""
            product_origin = ""
            product_tipo = ""
            product_color_tapiz = ""
            product_puestos = ""
            product_cuerpos = ""
            product_color_structure = ""
            product_pulgadas_tv = ""
            product_max_support_weight = ""
            product_plegable = ""
            product_ruedas = ""
            product_fijacion = ""
            product_space = ""
            product_repisas = ""
            product_cajones = ""
            product_puertas = ""
            product_apertura = ""
            product_guadarropa = ""

            product_cama_size = ""
            product_dimention_cama = ""
            product_recommand_age = ""
            product_com_level = ""
            product_composition = ""
            product_linea = ""
            product_material_colchone = ""
            product_color_colchone = ""
            product_guarantee = ""
            product_table_design = ""
            product_image = ""
            # Get the page content
            soup = BeautifulSoup(response.content, "html.parser")
            if soup.find("span", {"class":"title-content"}):
                pass
            else:
                product_soup = soup.find("div", {"class":"product-basic-info"})
                # with open("1.html", "w", encoding="utf-8") as file:
                #     file.write(str(product_soup))
                # Get the product info
                if product_soup.find("h1", {"class":"product-title"}):
                    product_name = product_soup.find("h1", {"class":"product-title"}).text
                product_price = product_soup.find("div", {"class":"pdp-price"}).find("div", {"class":"primary"}).text.replace("$", "").replace("und", "").replace(".","")
                # Get the specifications
                if product_soup.find("div", {"class":"sub-table-container"}):
                    specifications = str(product_soup.find("div", {"class":"sub-table-container"}))
                    specification_values = specifications.split('<div class="jsx-1675311072 element key">')[1:]
                    for specification_value in specification_values:
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Marca':
                            product_marca = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Material Tapiz':
                            product_material_tapiz = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Material Estructura':
                            product_material_structure = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Alto (centímetros)':
                            product_alto = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Ancho (centímetros)':
                            product_ancho = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Fondo (centímetros)':
                            product_fondo = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Alto':
                            product_alto = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Ancho':
                            product_ancho = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Fondo':
                            product_fondo = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Largo':
                            product_largo = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Profundidad (centímetros)':
                            product_profundidad = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Color':
                            product_color = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Capacidad (resistencia - carga máxima)':
                            product_capacity = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Peso del producto':
                            product_weight = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Garantía':
                            product_guarantee_time = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Origen':
                            product_origin = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Tipo':
                            product_tipo = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Color del tapiz':
                            product_color_tapiz = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Número de puestos':
                            product_puestos = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Material de la estructura':
                            product_material_structure = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'País de Origen':
                            product_origin = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Número de cuerpos':
                            product_cuerpos = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Color de la estructura':
                            product_color_structure = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Peso':
                            product_weight = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Pulgadas TV':
                            product_pulgadas_tv = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Material':
                            product_material_structure = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Peso máximo soportado':
                            product_max_support_weight = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Plegable':
                            product_plegable = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Cuenta con ruedas':
                            product_ruedas = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Modo de fijación':
                            product_fijacion = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Espacio recomendado':
                            product_space = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Cantidad de repisas':
                            product_repisas = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Cantidad de cajones':
                            product_cajones = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Cantidad de puertas':
                            product_puertas = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Tipo de guadarropa':
                            product_guadarropa = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Sistema de apertura':
                            product_apertura = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Tamaño de la cama':
                            product_cama_size = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Dimensiones de la cama':
                            product_dimention_cama = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Número de cajones':
                            product_cajones = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Edad recomendada':
                            product_recommand_age = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Nivel de Confort':
                            product_com_level = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Composición interna':
                            product_composition = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Línea':
                            product_linea = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Material Tapiz del Colchón':
                            product_material_colchone = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Color del Colchón':
                            product_color_colchone = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Garantía Producto':
                            product_guarantee = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                        if specification_value.split('</div><div class="jsx-1675311072 element value">')[0] == 'Diseño de la Mesa':
                            product_table_design = specification_value.split('</div><div class="jsx-1675311072 element value">')[1].split('</div></div')[0]
                product_code_txt = product_soup.find("div", {"class":"product-cod"}).text
                product_code = product_code_txt.split("Código ")[1]
                product_image = product_soup.find("img", {"id": f"pdpMainImage-{product_code}"})["src"]


                # Preview the results
                # print(product_name)
                # print(product_price)
                # print(product_image)
                # # Medidas
                # print(product_alto)
                # print(product_ancho)
                # print(product_fondo)
                # print(product_largo)
                # print(product_profundidad)  
                # # Specifications
                # print(product_marca)
                # print(product_material_tapiz)
                # print("structure ==>", product_material_structure)
                # print("color ==>", product_color)
                # print("capacity ==>", product_capacity)
                # print("weight ==>", product_weight)
                # print("guarantee time ==>", product_guarantee_time)
                # print("guarantee ==>", product_guarantee)
                # print("origin ==>", product_origin)
                # print("tipo ==>", product_tipo)
                # print("tapiz color ==>", product_color_tapiz)
                # print("puestos ==>", product_puestos)
                # print("cuerpos ==>", product_cuerpos)
                # print("color structure ==>", product_color_structure)
                # print("pulgadas TV ==>", product_pulgadas_tv)
                # print("max support weight==>", product_max_support_weight)
                # print("product table design ==>", product_table_design)
                # print("plegable ==>", product_plegable)
                # print("ruedas ==>", product_ruedas)
                # print("fijacion ==>", product_fijacion)
                # print("space ==>", product_space)
                # print("repisas ==>", product_repisas)
                # print("cajones ==>", product_cajones)
                # print("puertas ==>", product_puertas)
                # print("guadarropa ==>", product_guadarropa)
                # print("apertura ==>", product_apertura)
                # print("cama size ==>", product_cama_size)
                # print("cama dimention ==>", product_dimention_cama)
                # print("recommand age ==>", product_recommand_age)
                # print("com level ==>", product_com_level)
                # print("internal composition ==>", product_composition)
                # print("lenea ==>", product_linea)
                # print("colchone material ==>", product_material_colchone)
                # print("color colchone ==>", product_color_colchone)

                # JSON data
                product_result_data = {
                    "Categorias":"",
                    "Linea":"",
                    "Sublinea":"",
                    "Nombre":product_name,
                    "Precios": product_price,
                    # "Dimensiones":{
                        "Alto": product_alto,
                        "Ancho": product_ancho,
                        "Fondo":product_fondo,
                        "Largo":product_largo,
                        "Profundidad": product_profundidad,
                    # },
                    # "Especificaciones": {
                        "Material Estructura" : product_material_structure,
                        "Pais de Origen" : product_origin,
                        "Material Color" : product_color,
                        "Marca": product_marca,
                        "Material Tapiz" : product_material_tapiz,
                        "Capacity": product_capacity,
                        "Weight" : product_weight,
                        "Términos Garantía": product_guarantee_time,
                        "Tipo": product_tipo,
                        "Color de tapiz": product_color_tapiz,
                        "Número de cuerpos" : product_cuerpos,
                        "Garantía Producto" : product_guarantee,
                        "Número de puestos" : product_puestos,
                        "Color de la estructura" : product_color_structure,
                        "Pulgadas TV": product_pulgadas_tv,
                        "Peso maximo soportado" : product_max_support_weight,
                        "Diseño de la Mesa": product_table_design,
                        "Plegable": product_plegable,
                        "Cuenta con ruedas": product_ruedas,
                        "Modo de fijación": product_fijacion,
                        "Espacio recomendado":product_space,
                        "Cantidad de repisas": product_repisas,
                        "Cantidad de cajones": product_cajones,
                        "Cantidad de puertas": product_puertas,
                        "Tipo de guardarropa": product_guadarropa,
                        "Sistema de apertura": product_apertura,
                        "Dimensión cama": product_dimention_cama,
                        "Tamaño de la cama": product_cama_size,
                        "Edad recomendada": product_recommand_age,
                        "Nivel de confort": product_com_level,
                        "Composición interna": product_composition,
                        "Linea": product_linea,
                        "Material tapiz del colchon": product_material_colchone,
                        "Color del colchon": product_color_colchone,
                        "Image URL": product_image
                    # }
                }
                result.append(product_result_data)

                # with open("homecentersoup1.html", "w", encoding='utf-8') as file:
                #     file.write(str(soup.find("div", {"class":"product-basic-info"})))

                with open("homecenter.json", "w") as file:
                    json.dump(result, file, indent=2)

                with open("homecenter.json", "r") as file:
                    json_data = json.load(file)

                # Define fieldnames for CSV header
                fieldnames = json_data[0].keys()

                # Write JSON data to CSV
                with open("homecenter.csv", mode='w', newline='') as file:
                    writer = csv.DictWriter(file, fieldnames=fieldnames)
                    writer.writeheader()
                    for item in json_data:
                        writer.writerow(item)

    page = 1

        